module.exports = {
  LARGE_BODY_ALT: 'The console only shows bodies smaller than 10 KB in size. To view the complete body, inspect it in the Builder window.',
  MAX_BODY_SIZE: 1024 * 10
};
